<div class="auth-user-testimonial">
    <h3 class="mb-3 text-white">mewar HND to DEGREE TOPUP PORTAL</h3>
    <p class="lead fw-normal"><i class="mdi mdi-format-quote-open"></i> This Dedicated Gateway for your Higher National Diploma to Bachelors Degree topup is an exclusive platform launched to provide you a world of opportunities <i class="mdi mdi-format-quote-close"></i>
    </p>
    <h5 class="text-white">
        - Director Admissions Mewar Group
    </h5>
</div>
