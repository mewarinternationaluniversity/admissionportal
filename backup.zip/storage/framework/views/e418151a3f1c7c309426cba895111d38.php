<?php $__env->startPush('datepickercss'); ?>
    <link href="/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('datepickerjs'); ?>
    <script src="/js/bootstrap-datepicker.min.js"></script>
    <script src="/js/moment.min.js"></script>
<?php $__env->stopPush(); ?>

<h4 class="mt-0"><?php echo e(__('Student Login')); ?></h4>

<p class="text-muted mb-1">Enter your <b class="text-danger">Matriculation Number</b> and password to access portal.</p>

<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="loginby" id="loginby" value="student">

    <div class="mb-2">
        <label for="matriculation_no" class="form-label"><?php echo e(__('Matriculation Number')); ?></label>
        <input id="matriculation_no" type="text" class="form-control <?php $__errorArgs = ['matriculation_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="matriculation_no" value="<?php echo e(old('matriculation_no')); ?>" required autocomplete="matriculation_no" autofocus>

        <?php $__errorArgs = ['matriculation_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-2">
        <label for="password" class="form-label"><?php echo e(__('Date of birth')); ?></label>

        <div class="input-group input-group-merge">

            <div class="input-group position-relative" id="datepicker1">
                <input type="text" id="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-provide="datepicker" data-date-format="dd/mm/yyyy" data-date-container="#datepicker1">
                <span class="input-group-text"><i class="ri-calendar-event-fill"></i></span>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

            <label class="form-check-label" for="remember">
                <?php echo e(__('Remember Me')); ?>

            </label>
        </div>
    </div>
    <div class="d-grid text-center">
        <button class="btn btn-primary" type="submit"><?php echo e(__('Login')); ?> </button>
    </div>

    <div class="d-grid mt-2 text-center">
        <a href="<?php echo e(route('register')); ?>" class="btn btn-warning" type="button"><?php echo e(__('Register as a student')); ?> </a>
    </div>
</form><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/auth/student.blade.php ENDPATH**/ ?>