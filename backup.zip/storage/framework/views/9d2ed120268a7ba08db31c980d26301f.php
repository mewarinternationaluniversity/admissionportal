<div class="row">
    <div class="col-12">
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <i class="mdi mdi-block-helper me-2"></i> <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <i class="mdi mdi-check-all me-2"></i> <strong><?php echo e(session('success')); ?></strong>
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/status/index.blade.php ENDPATH**/ ?>