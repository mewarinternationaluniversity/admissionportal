<div class="auth-user-testimonial">
    <h3 class="mb-3 text-white">NBTE HND to DEGREE TOPUP PORTAL</h3>
    <p class="lead fw-normal"><i class="mdi mdi-format-quote-open"></i> This Dedicated Gateway for your Higher National Diploma to Bachelors Degree topup is an exclusive platform launched to provide you a world of opportunities through Universities across the Globe <i class="mdi mdi-format-quote-close"></i>
    </p>
    <h5 class="text-white">
        - Director Admissions National Board for Technical Education
    </h5>
</div>
<?php /**PATH /var/www/topup/admission/admissionportal/resources/views/partials/auth/auth-user-testimonial.blade.php ENDPATH**/ ?>