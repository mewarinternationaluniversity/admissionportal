<?php $__env->startSection('content'); ?>

    <?php $__env->startPush('datepicker'); ?>
        <link href="/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="/js/bootstrap-datepicker.min.js"></script>
        <script src="/js/moment.min.js"></script>
    <?php $__env->stopPush(); ?>

    <?php echo $__env->make('partials.body.breadcrumb', [
        'main' => 'Profile'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php
        $sessions = \App\Models\Session::get();
    ?>

    <div class="row">
        <div class="col-lg-4 col-xl-4">
            <?php echo $__env->make('users.profile.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8 col-xl-8">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('status.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <ul class="nav nav-pills navtab-bg">
                        <li class="nav-item">
                            <a href="#edit-profile" data-bs-toggle="tab" aria-expanded="true" class="nav-link ms-0 active">
                                <i class="mdi mdi-face-profile me-1"></i>Edit Profile
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#manage-password" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                                <i class="mdi mdi-cog me-1"></i>Manage Password
                            </a>
                        </li>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                            <li class="nav-item">
                                <a href="#session-manager" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                                    <i class="mdi mdi-alarm-light me-1"></i>Session Manager
                                </a>
                            </li>
                        <?php endif; ?>                        
                    </ul>
                    <div class="tab-content">                    
                        <div class="tab-pane active" id="edit-profile">
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                <?php echo $__env->make('users.profile.admin.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>

                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'manager')): ?>
                                <?php echo $__env->make('users.profile.manager.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>

                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'student')): ?>
                                <?php echo $__env->make('users.profile.student.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>                        
                        </div>
                        <div class="tab-pane" id="manage-password">
                            <?php echo $__env->make('users.profile.change-password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                            <div class="tab-pane" id="session-manager">
                                
                                <div class="row mb-2">
                                    <div class="col-sm-4">
                                        <h3>Session manager</h3>                                        
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="text-sm-end">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#addSession" class="btn btn-danger mb-2">
                                                <i class="mdi mdi-plus-circle me-1"></i> Add Session
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Session name</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($session->id); ?></th>
                                                    <td><?php echo e($session->name); ?></td>
                                                    <td>
                                                        <?php if($session->status == 1): ?>
                                                            <span class="badge badge-outline-success rounded-pill">Active</span>                                                        
                                                        <?php else: ?>
                                                            <span class="badge badge-outline-warning rounded-pill">Inactive</span>                                                        
                                                        <?php endif; ?>                                                    
                                                    </td>
                                                    <td>
                                                        <div class="button-list">
                                                            <button type="button" data-bs-toggle="modal" data-bs-target="#editSession_<?php echo e($session->id); ?>" class="btn btn-xs btn-success waves-effect waves-light"><i class="mdi mdi-lead-pencil"></i></button>
                                                            <a href="<?php echo e(route('admin.sessions.delete', $session->id)); ?>" onclick="return confirm('Are you sure?')" type="button" class="btn btn-xs btn-danger waves-effect waves-light"><i class="mdi mdi-close"></i></a>                                                        
                                                        </div>
                                                    </td>

                                                    <!-- Modal -->
                                                    <div class="modal fade" data-bs-backdrop="static" id="editSession_<?php echo e($session->id); ?>" tabindex="-1" aria-labelledby="editSession_<?php echo e($session->id); ?>Label" aria-hidden="true">

                                                        <div class="modal-dialog">
                                                            <div class="modal-content">                                                
                                                                <div class="modal-body">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="editSession_<?php echo e($session->id); ?>Label">Edit Session (<?php echo e($session->name); ?>)</h5>
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>

                                                                    <form method="post" action="<?php echo e(route('admin.sessions.store')); ?>" class="px-3" id="editsessionform" name="editsessionform">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="id" id="id" value="<?php echo e($session->id); ?>">
                                                            
                                                                        <div class="mb-3">
                                                                            <label for="name" class="form-label">Name</label>
                                                                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter Session" value="<?php echo e($session->name); ?>" required>
                                                                        </div>

                                                                        <div class="mb-3">
                                                                            <label for="status" class="form-label">Institute </label>
                                                                            <select class="form-control" name="status" required>
                                                                                <option <?php if($session->status == 1): echo 'selected'; endif; ?> value="1">Active</option>
                                                                                <option <?php if($session->status == 0): echo 'selected'; endif; ?> value="0">Inactive</option>
                                                                            </select>
                                                                        </div>                                                                        
                                                                        <div class="mb-3">
                                                                            <button class="btn btn-primary" type="submit">Edit Session</button>
                                                                        </div>
                                                            
                                                                    </form>        
                                                                </div>
                                                            </div>                                                
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- Add Session Modal -->
                                <div class="modal fade" data-bs-backdrop="static" id="addSession" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addSessionLabel">Add Session</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <form method="post" action="<?php echo e(route('admin.sessions.store')); ?>" class="px-3" id="addsessionform" name="addsessionform">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="mb-3">
                                                        <label for="name" class="form-label">Name</label>
                                                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Session name" required>
                                                    </div>                                
                                                    <div class="mb-3">
                                                        <label for="status" class="form-label">Session Status</label>
                                                        <select name="status" class="form-control" required>
                                                            <option value="">Please select</option>
                                                            <option value="1">Active</option>
                                                            <option value="0">Inactive</option>
                                                        </select>
                                                    </div>                                                    
                                                    <div class="mb-3">
                                                        <button class="btn btn-primary" type="submit">Add Session</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        <?php endif; ?>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.l', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/users/profile/index.blade.php ENDPATH**/ ?>