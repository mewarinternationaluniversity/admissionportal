<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.body.breadcrumb', [    
    'main' => 'Dashboard',
    // 'one' => [
    //     'title' => '',
    //     'route' => route('home'),
    // ],
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('status.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row mb-2">
                    <div class="col-sm-8"></div>
                    <div class="col-sm-4">
                        <div class="text-sm-end">

                            <div class="mb-2 row">
                                <label class="col-md-3 col-form-label" for="session">Session</label>
                                <div class="col-md-9">
                                    <?php
                                        $sessions = \App\Models\Session::get();
                                        $selected = '';
                                        if (isset($_GET['session'])) {
                                            $selected = $_GET['session'];
                                        }
                                    ?>
                                    <select class="form-control" name="session" id="session">
                                        <option value="">All sessions</option>
                                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($selected == $session->id): echo 'selected'; endif; ?> value="<?php echo e($session->id); ?>"><?php echo e($session->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive px-3">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Vacant seats</th>
                                <th>Approved seats</th>
                                <th>Male applications</th>
                                <th>Female applications</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $male = $course->applications()->with('student')->whereHas('student', function($q){
                                        $q->where('gender', 'Male');
                                    })->count();

                                    $female = $course->applications()->with('student')->whereHas('student', function($q){
                                        $q->where('gender', 'Female');
                                    })->count();
                                    $allpplications = $course->applications()->where('status', 'APPROVED')->count();

                                    $available = $course->pivot->seats - $allpplications;

                                ?>
                                <tr>
                                    <th><?php echo e($course->title); ?></th>
                                    <td><?php echo e($available); ?></td>
                                    <td><?php echo e($course->pivot->seats); ?></td>
                                    <td><?php echo e($male); ?></td>
                                    <td><?php echo e($female); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script type="text/javascript">
        $(function () {
            
            $("#session").change(function() {
                var $option = $(this).find(':selected');
                var sessionid = $option.val();
                if (sessionid != "") {
                    url = "?session=" + sessionid;
                    window.location.href = url;
                }else{
                    url = "?";
                    window.location.href = url;
                }
            });

        });
      </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.l', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/pages/dashboard/manager-b.blade.php ENDPATH**/ ?>