<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.body.breadcrumb', [    
    'main' => 'Step 2 Application',
    'one' => [
        'title' => 'Application',
        'route' => route('dashboard'),
    ],
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="row">
        <div class="text-center">
            <h2>NEW APPLICATION</h2>
            <p>List of institutes you are eligible based on your course selection. </p>
        </div>
        <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-md-6">
                <div class="widget-simple text-center card">
                    <div class="card-body">
                        <div class="mb-2">
                            <?php if($institute->logo): ?>
                                <div class="avatar-lg mx-auto">
                                    <img src="<?php echo e($institute->logo); ?>" class="img-fluid rounded-circle" alt="user">
                                </div>
                            <?php else: ?>
                                <div class="avatar-lg mx-auto">
                                    <div class="avatar-title rounded-circle bg-soft-primary fw-medium text-primary"><?php echo e(substr($institute->title, 0, 1)); ?></div>
                                </div>
                            <?php endif; ?>                            
                        </div>
                        <h4 class="header-title mt-0"><?php echo e($institute->title); ?></h4>

                        <?php
                            $seatsavailable = 0;

                            $applicationscount = App\Models\Application::where('institute_id', $institute->id)
                                                        ->where('status', 'APPROVED')
                                                        ->where('course_id', $course->id)->count();

                            $remaining = $institute->pivot->seats - $applicationscount;

                        ?>

                        <h5 class="text-success mt-0">
                            Seats Available : <small><?php echo e($remaining); ?> /<?php echo e($institute->pivot->seats); ?></small>
                        </h5>
                        <h5 class="text-warning mt-0">
                            Fees : USD <?php echo e($institute->pivot->fees); ?>

                        </h5>
                        <div class="mt-3">
                            <div class="d-grid gap-2 mb-2">
                                <a target="_blank" href="<?php echo e(route('institute.public.profile', $institute->id)); ?>" type="button" class="btn btn-warning waves-effect waves-light">
                                    <i class="mdi mdi-database-alert me-1"></i> Institute Profile Page
                                </a>
                            </div>
                            <div class="d-grid gap-2">
                                <?php if($remaining > 0): ?>
                                    <a href="<?php echo e(route('applications.student.stepthree', [$course->id, $institute->id])); ?>" type="button" class="btn btn-primary waves-effect waves-light">
                                        <i class="mdi mdi-plus-box me-1"></i> Apply
                                    </a>
                                <?php else: ?>
                                    <a href="#" type="button" disabled class="btn btn-primary waves-effect waves-light">
                                        <i class="mdi mdi-plus-box me-1"></i> Apply
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($institutes->links()); ?>       
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.l', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/applications/student/step2.blade.php ENDPATH**/ ?>