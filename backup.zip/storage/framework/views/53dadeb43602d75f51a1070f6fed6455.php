<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.body.breadcrumb', [
        'main' => 'Institute profile'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-lg-4 col-xl-4">
            <?php echo $__env->make('institute.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-8 col-xl-8">
            <div class="card">
                <div class="card-body">
                    <?php echo $__env->make('status.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="tab-content">
                        <div class="tab-pane active" id="edit-profile">
                            <?php echo $__env->make('institute.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.l', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/institute/profile.blade.php ENDPATH**/ ?>