<div class="card text-center">
    <div class="card-body">
        <?php if($user->avatar): ?>
            <img src="<?php echo e($user->avatar); ?>" class="rounded-circle avatar-xl img-thumbnail" alt="profile-image">            
        <?php else: ?>
            <img src="/img/avatar.png" class="rounded-circle avatar-xl img-thumbnail" alt="profile-image">            
        <?php endif; ?>
        <h4 class="mt-3 mb-0"><?php echo e($user->name); ?></h4>
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?><p class="text-muted">Admin</p><?php endif; ?>
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'student')): ?><p class="text-muted">Student</p><?php endif; ?>
        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'manager')): ?><p class="text-muted">Manager</p><?php endif; ?>

        <div class="text-start mt-3">
            <div class="table-responsive">

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                    <table class="table table-borderless table-sm">
                        <tbody>
                            <tr>
                                <th scope="row">Full Name :</th>
                                <td class="text-muted"><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Mobile :</th>
                                <td class="text-muted"><?php echo e($user->phone ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email :</th>
                                <td class="text-muted"><?php echo e($user->email); ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'manager')): ?>
                    <table class="table table-borderless table-sm">
                        <tbody>
                            <tr>
                                <th scope="row">Full Name :</th>
                                <td class="text-muted"><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Mobile :</th>
                                <td class="text-muted"><?php echo e($user->phone ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email :</th>
                                <td class="text-muted"><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Institute :</th>
                                <td class="text-muted"><?php echo e($user->institute->title ?? 'N/A'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'student')): ?>
                    <table class="table table-borderless table-sm">
                        <tbody>
                            <tr>
                                <th scope="row">Full Name :</th>
                                <td class="text-muted"><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Mobile :</th>
                                <td class="text-muted"><?php echo e($user->phone ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Email :</th>
                                <td class="text-muted"><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Matriculation Number :</th>
                                <td class="text-muted"><?php echo e($user->matriculation_no ?? 'N/A'); ?></td>
                            </tr>

                            <tr>
                                <th scope="row">Date of birth :</th>
                                <td class="text-muted"><?php echo e($user->dob ?? 'N/A'); ?></td>
                            </tr>

                            <tr>
                                <th scope="row">ND Institute :</th>
                                <td class="text-muted"><?php echo e($user->ndinstitute->title ?? 'N/A'); ?></td>
                            </tr>

                            <tr>
                                <th scope="row">ND Course :</th>
                                <td class="text-muted"><?php echo e($user->ndcourse->title ?? 'N/A'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/users/profile/details.blade.php ENDPATH**/ ?>