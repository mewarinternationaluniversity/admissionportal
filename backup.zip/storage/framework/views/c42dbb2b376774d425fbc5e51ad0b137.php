<?php $__env->startSection('content'); ?>
<div id="basicwizard">
    <ul class="nav nav-pills nav-justified form-wizard-header mb-4">
        <li class="nav-item">
            <a href="#student-tab" data-bs-toggle="tab" data-toggle="tab" class="nav-link active"> 
                <span class="number">1</span>
                <span class="d-none d-sm-inline"> Student Login</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="#admin-tab" data-bs-toggle="tab" data-toggle="tab" class="nav-link">
                <span class="number">2</span>
                <span class="d-none d-sm-inline"> Admin Login</span>
            </a>
        </li>
    </ul>

    <style>
        .tab-content {
            padding: 1px 0 0 0 !important;
        }
    </style>

    <div class="tab-content b-0 mb-0">
        <div class="tab-pane active" id="student-tab">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('auth.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        
        <div class="tab-pane" id="admin-tab">
            <div class="row">
                <div class="col-12">
                    <?php echo $__env->make('auth.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/auth/login.blade.php ENDPATH**/ ?>