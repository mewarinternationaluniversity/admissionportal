<form method="POST" action="<?php echo e(route('manager.institute.save')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="id" id="id" value="<?php echo e($institute->id); ?>">

    <h5 class="mb-3 text-uppercase bg-light p-2"><i class="mdi mdi-account-circle me-1"></i> <?php echo e(__('Institute Info')); ?></h5>

    <div class="row">
        <div class="col-md-6">
            <div class="mb-2">
                <label for="type" class="form-label"><?php echo e(__('Type')); ?></label>
                <select class="form-control" id="type" readonly>
                    <option><?php echo e($institute->type); ?></option>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-2">
                <label for="title" class="form-label"><?php echo e(__('Name')); ?></label>
                <input id="title" type="text" class="form-control" value="<?php echo e($institute->title); ?>" readonly>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="mb-2">
                <label for="officername" class="form-label"><?php echo e(__('Officer name')); ?></label>
                <input id="officername" type="text" class="form-control <?php $__errorArgs = ['officername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="officername" value="<?php echo e(old('officername', $institute->officername)); ?>" required>
    
                <?php $__errorArgs = ['officername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-md-4">
            <div class="mb-2">
                <label for="officeremail" class="form-label"><?php echo e(__('Officer email')); ?></label>
                <input id="officeremail" type="email" class="form-control <?php $__errorArgs = ['officeremail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="officeremail" value="<?php echo e(old('officeremail', $institute->officeremail)); ?>" required>
    
                <?php $__errorArgs = ['officeremail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-md-4">
            <div class="mb-2">
                <label for="phone" class="form-label"><?php echo e(__('Phone number')); ?></label>
                <input id="phone" type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" value="<?php echo e(old('phone', $institute->phone)); ?>" required>
    
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="mb-2">
                <label for="description" class="form-label"><?php echo e(__('Description')); ?></label>
                <textarea name="description" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" required><?php echo e(old('description', $institute->description)); ?></textarea>    
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <h5 class="mb-3 text-uppercase bg-light p-2">
        <i class="mdi mdi-file me-1"></i> Uploads
    </h5>

    <div class="table-responsive">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Preview Thumbnail</th>
                    <th>Replace</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td>Logo</td>
                    <td>
                        <?php if($institute->logo): ?>
                            <a href="<?php echo e(url($institute->logo)); ?>" target="_blank">
                                <img src="<?php echo e($institute->logo); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="logo" id="logo">
                    </td>
                </tr>
                <tr>
                    <th scope="row">1</th>
                    <td>Banner</td>
                    <td>
                        <?php if($institute->banner): ?>
                            <a href="<?php echo e(url($institute->banner)); ?>" target="_blank">
                                <img src="<?php echo e($institute->banner); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="banner" id="banner">
                    </td>
                </tr>
                <tr>
                    <th scope="row">1</th>
                    <td>Seal</td>
                    <td>
                        <?php if($institute->seal): ?>
                            <a href="<?php echo e(url($institute->seal)); ?>" target="_blank">
                                <img src="<?php echo e($institute->seal); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="seal" id="seal">
                    </td>
                </tr>
                <tr>
                    <th scope="row">1</th>
                    <td>Signature</td>
                    <td>
                        <?php if($institute->signature): ?>
                            <a href="<?php echo e(url($institute->signature)); ?>" target="_blank">
                                <img src="<?php echo e($institute->signature); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="signature" id="signature">
                    </td>
                </tr>
                <tr>
                    <th scope="row">1</th>
                    <td>Letter Head</td>
                    <td>
                        <?php if($institute->letterhead): ?>
                            <a href="<?php echo e(url($institute->letterhead)); ?>" target="_blank">
                                <img src="<?php echo e($institute->letterhead); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="letterhead" id="letterhead">
                    </td>
                </tr>

                <tr>
                    <th scope="row">1</th>
                    <td>Slider one</td>
                    <td>
                        <?php if($institute->sliderone): ?>
                            <a href="<?php echo e(url($institute->sliderone)); ?>" target="_blank">
                                <img src="<?php echo e($institute->sliderone); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="sliderone" id="sliderone">
                    </td>
                </tr>

                <tr>
                    <th scope="row">1</th>
                    <td>Slider Two</td>
                    <td>
                        <?php if($institute->slidertwo): ?>
                            <a href="<?php echo e(url($institute->slidertwo)); ?>" target="_blank">
                                <img src="<?php echo e($institute->slidertwo); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="slidertwo" id="slidertwo">
                    </td>
                </tr>

                <tr>
                    <th scope="row">1</th>
                    <td>Slider Three</td>
                    <td>
                        <?php if($institute->sliderthree): ?>
                            <a href="<?php echo e(url($institute->sliderthree)); ?>" target="_blank">
                                <img src="<?php echo e($institute->sliderthree); ?>" alt="image" class="img-fluid img-thumbnail" width="100">
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="file" class="form-control" name="sliderthree" id="sliderthree">
                    </td>
                </tr>                
            </tbody>
        </table>
    </div>

    <div class="text-end">
        <button type="submit" class="btn btn-success waves-effect waves-light mt-2">
            <i class="mdi mdi-content-save"></i> <?php echo e(__('Save')); ?>

        </button>
    </div>
</form><?php /**PATH /var/www/topup/admission/admissionportal/resources/views/institute/edit.blade.php ENDPATH**/ ?>