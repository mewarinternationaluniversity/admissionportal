<?php

namespace App\Enums;

use Spatie\Enum\Laravel\Enum;

/**
 * @method static self DIPLOMA()
 * @method static self BACHELORS()
 */

 final class CourseTypeEnum extends Enum {}