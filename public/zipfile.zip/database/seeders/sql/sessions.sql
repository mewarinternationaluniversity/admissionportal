-- Adminer 4.8.1 MySQL 10.4.10-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

INSERT INTO `sessions` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1,	'2023/2024',	NULL,	1,	'2023-07-19 14:07:44',	'2023-07-19 14:08:14'),
(2,	'2024/2025',	NULL,	0,	'2023-07-19 14:08:04',	'2023-07-19 14:08:14');

-- 2023-07-20 05:48:42