<div class="auth-user-testimonial">
<img src="https://upload.wikimedia.org/wikipedia/en/1/1e/NBTE_logo.jpeg" alt="Trulli" width="25%" height="25%">
    <h3 class="mb-3 text-white">NBTE APPROVED HND TO DEGREE TOPUP PORTAL</h3>
    <p class="lead fw-normal"><i class="mdi mdi-format-quote-open"></i> This Dedicated Gateway for your NBTE approved Higher National Diploma to Bachelors Degree topup is an exclusive platform launched to provide you a world of opportunities <i class="mdi mdi-format-quote-close"></i>
    </p>
    <h5 class="text-white">National Board for Technical Education
    </h5>
</div>
